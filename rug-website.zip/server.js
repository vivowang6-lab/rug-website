const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// 中间件
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// ============ 模拟数据库 ============
const mockCarpets = [
  {
    id: 1,
    name: 'Aura I',
    brand: 'Tai Ping',
    style: 'modern',
    image: 'https://via.placeholder.com/300x300?text=Aura+I',
    price: '¥2,880/㎡',
    description: '粉彩色系，柔和流动的大理石纹理',
    created_at: new Date()
  },
  {
    id: 2,
    name: 'Element I',
    brand: 'Tai Ping',
    style: 'modern',
    image: 'https://via.placeholder.com/300x300?text=Element+I',
    price: '¥2,580/㎡',
    description: '大地色系，简洁垂直线条纹理',
    created_at: new Date()
  },
  {
    id: 3,
    name: 'Ionic I',
    brand: 'Tai Ping',
    style: 'geometric',
    image: 'https://via.placeholder.com/300x300?text=Ionic+I',
    price: '¥3,180/㎡',
    description: '冰川蓝调，流动扭曲的视觉纹理',
    created_at: new Date()
  }
];

const materials = require('./api/data/materials');
const templates = require('./api/data/templates');

// ============ API 路由 ============

// 获取地毯列表
app.get('/api/carpets', (req, res) => {
  res.json(mockCarpets);
});

// 添加地毯
app.post('/api/carpets', (req, res) => {
  const newCarpet = {
    id: mockCarpets.length + 1,
    ...req.body,
    created_at: new Date()
  };
  mockCarpets.push(newCarpet);
  res.json(newCarpet);
});

// AI 文案生成
app.post('/api/generate', (req, res) => {
  const { material_id, platform, scene } = req.body;

  if (!material_id || !platform) {
    return res.status(400).json({
      error: 'Missing required fields',
      required: ['material_id', 'platform']
    });
  }

  const material = materials.find(m => m.id === material_id);
  if (!material) {
    return res.status(404).json({
      error: 'Material not found',
      available: materials.map(m => m.id)
    });
  }

  const validPlatforms = ['xiaohongshu', 'instagram'];
  if (!validPlatforms.includes(platform)) {
    return res.status(400).json({
      error: 'Invalid platform',
      valid: validPlatforms
    });
  }

  const validScenes = ['luxury', 'minimalist', 'wabisabi', 'modern'];
  const finalScene = validScenes.includes(scene) ? scene : 'modern';

  const platformTemplates = templates[platform][finalScene];
  const template = platformTemplates[Math.floor(Math.random() * platformTemplates.length)];

  const replacements = {
    '[材质名]': material.name,
    '[材质特征]': material.texture,
    '[纹理]': material.texture,
    '[色系]': material.colorScheme,
    '[工艺]': material.technique,
    '[价格]': material.price,
    '[适用]': material.suitable,
    '[Material]': material.name,
    '[Texture]': material.texture,
    '[Color]': material.colorScheme,
    '[Technique]': material.technique,
    '[Price]': material.price,
    '[Suitable]': material.suitable
  };

  let title = template.title;
  let content = template.content;
  let tips = template.tips;

  Object.keys(replacements).forEach(key => {
    const regex = new RegExp(key, 'g');
    title = title.replace(regex, replacements[key]);
    content = content.replace(regex, replacements[key]);
    tips = tips.replace(regex, replacements[key]);
  });

  let hashtags = template.hashtags.map(tag => {
    let result = tag;
    Object.keys(replacements).forEach(key => {
      result = result.replace(new RegExp(key, 'g'), replacements[key]);
    });
    return result;
  });

  res.json({
    success: true,
    data: {
      material_id: material.id,
      material_name: material.name,
      platform,
      scene: finalScene,
      result: { title, content, hashtags, tips },
      material_info: {
        colorScheme: material.colorScheme,
        material: material.material,
        technique: material.technique,
        suitable: material.suitable,
        price: material.price
      }
    }
  });
});

// 获取材质列表
app.get('/api/materials', (req, res) => {
  res.json(materials);
});

// 获取模板
app.get('/api/templates', (req, res) => {
  res.json(templates);
});

// 健康检查
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date() });
});

// 错误处理
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Internal server error' });
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`🚀 服务器运行在 http://localhost:${PORT}`);
  console.log(`📖 打开浏览器访问: http://localhost:${PORT}`);
});
