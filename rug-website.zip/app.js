// ============ 全局配置 ============
const API_BASE = '/api';
let currentCategory = 'all';
let selectedPlatform = null;
let selectedScene = null;
let selectedCarpet = null;

// ============ 初始化 ============
document.addEventListener('DOMContentLoaded', async () => {
  await loadCarpets();
  await loadScenes();
  await loadMagazine();
  await loadContentCalendar();
  populateCarpetSelect();
});

// ============ 风格画廊 ============
async function loadCarpets() {
  try {
    const response = await fetch(`${API_BASE}/carpets`);
    const carpets = await response.json();
    
    // 模拟数据（如果 API 失败）
    const mockCarpets = [
      {
        id: 1,
        name: 'Aura I',
        brand: 'Tai Ping',
        style: 'modern',
        image: 'https://via.placeholder.com/300x300?text=Aura+I',
        price: '¥2,880/㎡',
        description: '粉彩色系，柔和流动的大理石纹理'
      },
      {
        id: 2,
        name: 'Element I',
        brand: 'Tai Ping',
        style: 'modern',
        image: 'https://via.placeholder.com/300x300?text=Element+I',
        price: '¥2,580/㎡',
        description: '大地色系，简洁垂直线条纹理'
      },
      {
        id: 3,
        name: 'Ionic I',
        brand: 'Tai Ping',
        style: 'geometric',
        image: 'https://via.placeholder.com/300x300?text=Ionic+I',
        price: '¥3,180/㎡',
        description: '冰川蓝调，流动扭曲的视觉纹理'
      },
      {
        id: 4,
        name: 'Nova I',
        brand: 'Tai Ping',
        style: 'luxury',
        image: 'https://via.placeholder.com/300x300?text=Nova+I',
        price: '¥4,580/㎡',
        description: '奢华金色调，流体动力学线条'
      },
      {
        id: 5,
        name: 'Vapour I',
        brand: 'Tai Ping',
        style: 'persian',
        image: 'https://via.placeholder.com/300x300?text=Vapour+I',
        price: '¥2,680/㎡',
        description: '云雾灰调，细腻丝滑触感'
      },
      {
        id: 6,
        name: 'Vortex I',
        brand: 'Tai Ping',
        style: 'geometric',
        image: 'https://via.placeholder.com/300x300?text=Vortex+I',
        price: '¥3,880/㎡',
        description: '灰白带金，3D地质层叠纹理'
      }
    ];

    const data = response.ok ? carpets : mockCarpets;
    renderCarpets(data);
  } catch (error) {
    console.error('加载地毯失败:', error);
    // 使用模拟数据
    renderCarpets(mockCarpets);
  }
}

function renderCarpets(carpets) {
  const grid = document.getElementById('products-grid');
  const filtered = currentCategory === 'all' 
    ? carpets 
    : carpets.filter(c => c.style === currentCategory);

  grid.innerHTML = filtered.map(carpet => `
    <div class="glass rounded-2xl overflow-hidden group hover:border-red/50 transition-all duration-300 cursor-pointer" onclick="selectCarpet(${carpet.id})">
      <div class="relative overflow-hidden h-64 bg-gradient-to-br from-gray-800 to-black">
        <img src="${carpet.image}" alt="${carpet.name}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
      </div>
      <div class="p-6">
        <div class="flex justify-between items-start mb-3">
          <div>
            <p class="text-xs text-gray-500 mb-1">${carpet.brand}</p>
            <h3 class="font-bold text-lg">${carpet.name}</h3>
          </div>
          <span class="text-red font-bold text-sm">${carpet.price}</span>
        </div>
        <p class="text-sm text-gray-400 mb-4">${carpet.description}</p>
        <button class="w-full bg-red/10 hover:bg-red/20 text-red py-2 rounded-lg text-sm transition">
          查看详情
        </button>
      </div>
    </div>
  `).join('');
}

function filterCategory(category) {
  currentCategory = category;
  document.querySelectorAll('.category-tab').forEach(tab => {
    tab.classList.remove('active');
  });
  event.target.classList.add('active');
  loadCarpets();
}

function selectCarpet(id) {
  selectedCarpet = id;
  alert(`已选择地毯 #${id}`);
}

// ============ 场景搭配 ============
async function loadScenes() {
  const scenes = [
    {
      name: '现代极简',
      image: 'https://via.placeholder.com/400x300?text=Modern+Minimalist',
      carpets: 3,
      description: '简洁线条，大气空间'
    },
    {
      name: '奢华别墅',
      image: 'https://via.placeholder.com/400x300?text=Luxury+Villa',
      carpets: 5,
      description: '金色调，高端质感'
    },
    {
      name: '温馨家居',
      image: 'https://via.placeholder.com/400x300?text=Cozy+Home',
      carpets: 4,
      description: '暖色系，舒适氛围'
    }
  ];

  const grid = document.getElementById('scenes-grid');
  grid.innerHTML = scenes.map(scene => `
    <div class="glass rounded-2xl overflow-hidden group cursor-pointer hover:border-red/50 transition-all">
      <div class="relative h-48 overflow-hidden">
        <img src="${scene.image}" alt="${scene.name}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300">
        <div class="scene-overlay absolute inset-0"></div>
      </div>
      <div class="p-6 relative z-10">
        <h3 class="font-bold text-lg mb-2">${scene.name}</h3>
        <p class="text-sm text-gray-400 mb-4">${scene.description}</p>
        <div class="flex justify-between items-center">
          <span class="text-xs text-gray-500">${scene.carpets} 款推荐</span>
          <button class="text-red hover:text-red-dark transition">查看 →</button>
        </div>
      </div>
    </div>
  `).join('');
}

// ============ AI 内容工坊 ============
function populateCarpetSelect() {
  const select = document.getElementById('studio-carpet');
  const carpets = [
    { id: 'TP-001', name: 'Aura I - 粉彩色系' },
    { id: 'TP-002', name: 'Element I - 大地色系' },
    { id: 'TP-003', name: 'Ionic I - 冰川蓝调' },
    { id: 'TP-004', name: 'Nova I - 奢华金色调' },
    { id: 'TP-005', name: 'Vapour I - 云雾灰调' }
  ];

  select.innerHTML = '<option value="">请选择要推广的地毯...</option>' + 
    carpets.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
}

function selectStudioPlatform(platform) {
  selectedPlatform = platform;
  document.querySelectorAll('.studio-platform').forEach(btn => {
    btn.style.borderColor = 'rgba(255,255,255,0.1)';
  });
  event.target.closest('.studio-platform').style.borderColor = '#e30614';
}

function selectStudioScene(scene) {
  selectedScene = scene;
  document.querySelectorAll('.studio-scene').forEach(btn => {
    btn.style.borderColor = 'rgba(255,255,255,0.1)';
  });
  event.target.style.borderColor = '#e30614';
}

async function generateStudioContent() {
  const carpetSelect = document.getElementById('studio-carpet');
  const materialId = carpetSelect.value;

  if (!materialId || !selectedPlatform) {
    alert('请选择地毯和平台');
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        material_id: materialId,
        platform: selectedPlatform,
        scene: selectedScene || 'modern'
      })
    });

    const result = await response.json();
    
    if (result.success) {
      displayGeneratedContent(result.data);
    } else {
      alert('生成失败: ' + result.error);
    }
  } catch (error) {
    console.error('生成内容失败:', error);
    // 使用模拟数据
    displayGeneratedContent({
      result: {
        title: '✨ 豪宅标配 | 这块地毯让客厅身价翻倍',
        content: '终于找到梦中情毯！柔和流动的大理石纹理的Aura I，粉彩色系配色直接美哭😭\n\n💫 工艺：流动大理石纹理\n💰 价格：¥2,880/㎡\n\n铺在客厅瞬间提升N个档次，客人来了都问链接！',
        hashtags: ['Aura I', '地毯推荐', '家居美学', '客厅地毯', '设计师同款', '装修灵感']
      }
    });
  }
}

function displayGeneratedContent(data) {
  const output = document.getElementById('studio-output');
  const { title, content, hashtags } = data.result;

  output.innerHTML = `
    <div class="space-y-4">
      <div class="p-4 rounded-xl bg-white/5 border border-white/10">
        <h4 class="font-bold text-lg mb-3 text-red">${title}</h4>
        <p class="text-sm text-gray-300 whitespace-pre-wrap mb-4">${content}</p>
        <div class="flex flex-wrap gap-2">
          ${hashtags.map(tag => `<span class="text-xs px-3 py-1 rounded-full bg-red/10 text-red">#${tag}</span>`).join('')}
        </div>
      </div>
      <div class="flex gap-3">
        <button onclick="copyToClipboard('${title}\\n\\n${content}\\n\\n${hashtags.map(t => '#' + t).join(' ')}')" class="flex-1 bg-red hover:bg-red-dark py-2 rounded-lg text-sm transition">
          复制文案
        </button>
        <button onclick="downloadContent('${title}', '${content}')" class="flex-1 border border-white/20 hover:bg-white/5 py-2 rounded-lg text-sm transition">
          下载
        </button>
      </div>
    </div>
  `;
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    alert('已复制到剪贴板！');
  });
}

function downloadContent(title, content) {
  const element = document.createElement('a');
  element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(title + '\n\n' + content));
  element.setAttribute('download', 'content.txt');
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}

// ============ 内容日历 ============
async function loadContentCalendar() {
  const calendar = document.getElementById('content-calendar');
  const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];
  const statuses = ['pending', 'draft', 'scheduled', 'published', 'pending', 'draft', 'scheduled'];

  calendar.innerHTML = days.map((day, i) => `
    <div class="glass rounded-xl p-4 text-center group hover:border-red/50 transition cursor-pointer">
      <p class="text-xs text-gray-500 mb-2">${day}</p>
      <div class="w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center text-xs font-bold
        ${statuses[i] === 'published' ? 'bg-green-500/20 text-green-500' : 
          statuses[i] === 'scheduled' ? 'bg-blue-500/20 text-blue-500' :
          statuses[i] === 'draft' ? 'bg-yellow-500/20 text-yellow-500' :
          'bg-gray-500/20 text-gray-500'}">
        ${i + 1}
      </div>
      <p class="text-xs text-gray-400">
        ${statuses[i] === 'published' ? '已发布' :
          statuses[i] === 'scheduled' ? '待发布' :
          statuses[i] === 'draft' ? '草稿' :
          '待创建'}
      </p>
    </div>
  `).join('');
}

// ============ 以图搜图 ============
function handleVisualSearch(input) {
  if (input.files && input.files[0]) {
    const reader = new FileReader();
    reader.onload = (e) => {
      // 模拟 AI 分析
      const results = [
        { name: 'Aura I', similarity: 95, price: '¥2,880/㎡' },
        { name: 'Element I', similarity: 87, price: '¥2,580/㎡' },
        { name: 'Ionic I', similarity: 82, price: '¥3,180/㎡' }
      ];

      displaySearchResults(results);
    };
    reader.readAsDataURL(input.files[0]);
  }
}

function displaySearchResults(results) {
  const resultsDiv = document.getElementById('search-results');
  const productsDiv = document.getElementById('similar-products');
  
  document.getElementById('search-count').textContent = results.length + '款';
  
  productsDiv.innerHTML = results.map(r => `
    <div class="glass rounded-2xl overflow-hidden group hover:border-red/50 transition">
      <div class="h-48 bg-gradient-to-br from-gray-800 to-black flex items-center justify-center">
        <div class="text-center">
          <div class="text-4xl mb-2">🎯</div>
          <p class="text-sm text-gray-500">相似度 ${r.similarity}%</p>
        </div>
      </div>
      <div class="p-4">
        <h4 class="font-bold mb-2">${r.name}</h4>
        <p class="text-sm text-red mb-3">${r.price}</p>
        <button class="w-full bg-red/10 hover:bg-red/20 text-red py-2 rounded-lg text-sm transition">
          查看详情
        </button>
      </div>
    </div>
  `).join('');
  
  resultsDiv.classList.remove('hidden');
}

// ============ 本周杂志 ============
async function loadMagazine() {
  const toc = document.getElementById('magazine-toc');
  const content = document.getElementById('magazine-content');

  const articles = [
    { title: '自然材质回归', icon: '🌿', count: 1 },
    { title: '大尺寸地毯需求', icon: '📏', count: 2 },
    { title: '渐变色彩设计', icon: '🎨', count: 3 },
    { title: '设计师推荐', icon: '⭐', count: 4 }
  ];

  toc.innerHTML = articles.map((a, i) => `
    <div class="glass rounded-xl p-4 text-center cursor-pointer hover:border-red/50 transition group">
      <div class="text-3xl mb-2 group-hover:scale-110 transition">${a.icon}</div>
      <p class="text-sm font-medium">${a.title}</p>
      <p class="text-xs text-gray-500 mt-1">P.${a.count}</p>
    </div>
  `).join('');

  content.innerHTML = articles.map((a, i) => `
    <div class="border-t border-white/10 pt-12">
      <div class="flex items-center gap-4 mb-6">
        <div class="text-5xl">${a.icon}</div>
        <div>
          <p class="text-red text-sm">第 ${i + 1} 篇</p>
          <h3 class="font-serif text-3xl font-bold">${a.title}</h3>
        </div>
      </div>
      <p class="text-gray-400 leading-relaxed mb-6">
        这是关于"${a.title}"的详细内容。在本期杂志中，我们深入探讨了这一趋势的发展背景、市场表现和未来前景。
        通过数据分析和专家观点，为您呈现最全面的行业洞察。
      </p>
      <div class="grid md:grid-cols-3 gap-4">
        <div class="glass rounded-xl p-4 text-center">
          <p class="text-2xl font-bold text-red mb-2">↑ 156%</p>
          <p class="text-xs text-gray-500">搜索增长</p>
        </div>
        <div class="glass rounded-xl p-4 text-center">
          <p class="text-2xl font-bold text-blue-400 mb-2">12K</p>
          <p class="text-xs text-gray-500">相关笔记</p>
        </div>
        <div class="glass rounded-xl p-4 text-center">
          <p class="text-2xl font-bold text-green-400 mb-2">89%</p>
          <p class="text-xs text-gray-500">好评率</p>
        </div>
      </div>
    </div>
  `).join('');
}

// ============ 管理后台 ============
function addWebsite() {
  const url = prompt('请输入网站 URL:');
  if (url) {
    alert('已添加网站: ' + url);
  }
}

// ============ 其他功能 ============
function toggleMobileMenu() {
  const menu = document.getElementById('mobile-menu');
  menu.classList.toggle('hidden');
}

function shareMagazine() {
  alert('分享功能已准备就绪！');
}
